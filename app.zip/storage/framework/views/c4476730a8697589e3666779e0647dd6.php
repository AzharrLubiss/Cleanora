<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name', 'Aplikasi')); ?></title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom Color Palette -->
    <style>
        :root {
            /* Palette Dominan: Fresh */
            --bg-fresh: #f0fdf4;
            --main-fresh: #059669;
            --dark-fresh: #047857;
            
            /* Palette Aksen & Highlight */
            --vermillion: #e11d48;
            --vermillion-hover: #be123c;
            --sunshine: #f59e0b;
        }

        body {
            background-color: var(--bg-fresh);
            color: #334155;
            font-family: system-ui, -apple-system, sans-serif;
        }

        /* Navbar Custom */
        .navbar-fresh {
            background-color: var(--main-fresh);
        }

        /* Card Elegan */
        .card-custom {
            border: 1px solid #dcfce7;
            border-radius: 16px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(8px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .card-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06);
        }

        /* Tombol Aksen Vermillion */
        .btn-vermillion {
            background-color: var(--vermillion);
            color: #ffffff;
            border: none;
            border-radius: 10px;
            font-weight: 600;
        }

        .btn-vermillion:hover {
            background-color: var(--vermillion-hover);
            color: #ffffff;
        }

        /* Badge Sunshine */
        .badge-sunshine {
            background-color: #fef3c7;
            color: #b45309;
            border: 1px solid #fde68a;
            font-weight: 600;
        }
    </style>
</head>
<body>

    <!-- Navigasi -->
    <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Header / Banner -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($header)): ?>
        <header class="bg-white border-bottom py-3 shadow-sm">
            <div class="container">
                <?php echo e($header); ?>

            </div>
        </header>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <!-- Content Utama -->
    <main class="container py-4">
        <?php echo e($slot); ?>

    </main>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\laundry\resources\views/layouts/app.blade.php ENDPATH**/ ?>