<nav class="navbar navbar-expand-lg navbar-dark navbar-fresh shadow-sm sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?php echo e(route('home')); ?>">
            Dashboard<span style="color: var(--sunshine);">.</span>
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('home')); ?>">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('layanan')); ?>">Layanan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('pesanan.index')); ?>">Pesanan</a>
                </li>
            </ul>

            <!-- Button CTA Vermillion -->
            <div class="d-flex">
                <a href="<?php echo e(route('pesanan.create')); ?>" class="btn btn-vermillion px-3 py-2">
                    + Buat Pesanan
                </a>
            </div>
        </div>
    </div>
</nav><?php /**PATH C:\laragon\www\laundry\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>