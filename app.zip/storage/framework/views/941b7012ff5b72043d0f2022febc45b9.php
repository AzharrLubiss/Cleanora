<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="container py-5">

    
    <div class="mb-4">

        <h2 class="fw-bold">
            Halo, <?php echo e($user->name); ?> 
        </h2>

        <p class="text-muted">
            Selamat datang di Dashboard Pelanggan Cleanora Laundry.
        </p>

    </div>

    
    <div class="row g-4 mb-5">

        <div class="col-lg-4">

            <div class="card shadow border-0 h-100">

                <div class="card-body text-center">

                    <i class="bi bi-bag-check-fill text-primary fs-1"></i>

                    <h5 class="mt-3">
                        Total Pesanan
                    </h5>

                    <h2 class="fw-bold">
                        <?php echo e($jumlahPesanan); ?>

                    </h2>

                </div>

            </div>

        </div>

        <div class="col-lg-4">

            <div class="card shadow border-0 h-100">

                <div class="card-body text-center">

                    <i class="bi bi-clock-history text-warning fs-1"></i>

                    <h5 class="mt-3">
                        Status Terbaru
                    </h5>

                    <h4 class="fw-bold">

                        <?php echo e($pesananTerbaru->status ?? 'Belum Ada Pesanan'); ?>


                    </h4>

                </div>

            </div>

        </div>

        <div class="col-lg-4">

            <div class="card shadow border-0 h-100">

                <div class="card-body text-center">

                    <i class="bi bi-plus-circle-fill text-success fs-1"></i>

                    <h5 class="mt-3">
                        Buat Pesanan
                    </h5>

                    <a href="<?php echo e(route('pesanan.create')); ?>"
                        class="btn btn-success mt-2">

                        Pesan Laundry

                    </a>

                </div>

            </div>

        </div>

    </div>

    
    <div class="card shadow border-0">

        <div class="card-header bg-primary text-white">

            <h5 class="mb-0">

                Pesanan Terbaru

            </h5>

        </div>

        <div class="card-body">

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pesananTerbaru): ?>

            <table class="table">

                <tr>
                    <th>Kode Pesanan</th>
                    <td><?php echo e($pesananTerbaru->kode_pesanan); ?></td>
                </tr>

                <tr>
                    <th>Layanan</th>
                    <td><?php echo e($pesananTerbaru->layanan->nama); ?></td>
                </tr>

                <tr>
                    <th>Berat</th>
                    <td><?php echo e($pesananTerbaru->berat); ?> Kg</td>
                </tr>

                <tr>
                    <th>Total Harga</th>
                    <td>
                        Rp <?php echo e(number_format($pesananTerbaru->total_harga,0,',','.')); ?>

                    </td>
                </tr>

                <tr>
                    <th>Status</th>

                    <td>

                        <span class="badge bg-primary">

                            <?php echo e($pesananTerbaru->status); ?>


                        </span>

                    </td>

                </tr>

            </table>

            <?php else: ?>

            <div class="alert alert-info">

                Anda belum memiliki pesanan.

            </div>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pelanggan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laundry\resources\views/dashboard.blade.php ENDPATH**/ ?>