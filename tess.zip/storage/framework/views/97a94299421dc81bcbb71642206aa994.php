

<?php $__env->startSection('title', 'Pesan Laundry - Cleanora'); ?>

<?php $__env->startSection('content'); ?>

<section class="py-5">
    <div class="container" style="max-width: 850px;">

        <div class="mb-4">
            <h2 class="fw-bold">Pesan Laundry</h2>
            <p class="text-muted">
                Isi data berikut untuk membuat pesanan laundry.
            </p>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <li><?php echo e($error); ?></li>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </ul>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-4">

                <form action="<?php echo e(route('pesanan.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">
                            Pilih Layanan
                        </label>

                        <select
                            name="layanan_id"
                            id="layanan_id"
                            class="form-select"
                            required
                        >
                            <option value="">-- Pilih Layanan --</option>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $layanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <option
                                    value="<?php echo e($layanan->id); ?>"
                                    data-harga="<?php echo e($layanan->harga_per_kg); ?>"
                                    <?php echo e(old('layanan_id') == $layanan->id ? 'selected' : ''); ?>

                                >
                                    <?php echo e($layanan->nama); ?>

                                    - Rp <?php echo e(number_format($layanan->harga_per_kg, 0, ',', '.')); ?>/Kg
                                </option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">
                            Berat Laundry (Kg)
                        </label>

                        <input
                            type="number"
                            name="berat"
                            id="berat"
                            class="form-control"
                            min="1"
                            step="0.1"
                            value="<?php echo e(old('berat')); ?>"
                            required
                        >
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">
                            Catatan
                        </label>

                        <textarea
                            name="catatan"
                            class="form-control"
                            rows="4"
                            placeholder="Contoh: Pisahkan pakaian putih..."
                        ><?php echo e(old('catatan')); ?></textarea>
                    </div>

                    <div class="alert alert-primary">
                        <div class="d-flex justify-content-between">
                            <span class="fw-semibold">Perkiraan Total</span>
                            <strong id="totalHarga">Rp 0</strong>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <a
                            href="<?php echo e(route('dashboard')); ?>"
                            class="btn btn-outline-secondary"
                        >
                            Kembali
                        </a>

                        <button
                            type="submit"
                            class="btn btn-primary flex-grow-1"
                        >
                            <i class="bi bi-bag-check me-1"></i>
                            Buat Pesanan
                        </button>
                    </div>

                </form>

            </div>
        </div>

    </div>
</section>

<script>
    const layanan = document.getElementById('layanan_id');
    const berat = document.getElementById('berat');
    const totalHarga = document.getElementById('totalHarga');

    function hitungTotal() {
        const selected = layanan.options[layanan.selectedIndex];
        const harga = Number(selected.dataset.harga || 0);
        const jumlahBerat = Number(berat.value || 0);

        const total = harga * jumlahBerat;

        totalHarga.textContent =
            'Rp ' + total.toLocaleString('id-ID');
    }

    layanan.addEventListener('change', hitungTotal);
    berat.addEventListener('input', hitungTotal);

    hitungTotal();
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pelanggan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laundry\resources\views/pesanan/create.blade.php ENDPATH**/ ?>