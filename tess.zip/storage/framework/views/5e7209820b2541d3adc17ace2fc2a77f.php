

<?php $__env->startSection('title', 'Riwayat Pesanan - Cleanora'); ?>

<?php $__env->startSection('content'); ?>

<section class="py-5">
    <div class="container">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="fw-bold mb-1">Riwayat Pesanan</h2>
                <p class="text-muted mb-0">
                    Semua pesanan laundry Anda.
                </p>
            </div>

            <a href="<?php echo e(route('pesanan.create')); ?>"
               class="btn btn-primary">
                <i class="bi bi-plus-lg me-1"></i>
                Pesan Laundry
            </a>
        </div>

        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body">

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                    <div class="border-bottom py-3">
                        <div class="row align-items-center g-3">

                            <div class="col-md-3">
                                <small class="text-muted">Kode Pesanan</small>
                                <div class="fw-bold">
                                    <?php echo e($pesanan->kode_pesanan); ?>

                                </div>
                            </div>

                            <div class="col-md-2">
                                <small class="text-muted">Layanan</small>
                                <div>
                                    <?php echo e($pesanan->layanan->nama); ?>

                                </div>
                            </div>

                            <div class="col-md-2">
                                <small class="text-muted">Berat</small>
                                <div>
                                    <?php echo e($pesanan->berat); ?> Kg
                                </div>
                            </div>

                            <div class="col-md-2">
                                <small class="text-muted">Total</small>
                                <div class="fw-semibold">
                                    Rp <?php echo e(number_format($pesanan->total_harga, 0, ',', '.')); ?>

                                </div>
                            </div>

                            <div class="col-md-2">
                                <small class="text-muted">Status</small>

                                <div>
                                    <?php
                                        $statusClass = match($pesanan->status) {
                                            'menunggu' => 'bg-secondary',
                                            'dicuci' => 'bg-primary',
                                            'dikeringkan' => 'bg-info text-dark',
                                            'disetrika' => 'bg-warning text-dark',
                                            'siap_diambil' => 'bg-success',
                                            'selesai' => 'bg-dark',
                                            default => 'bg-secondary',
                                        };
                                    ?>

                                    <span class="badge <?php echo e($statusClass); ?>">
                                        <?php echo e(ucwords(str_replace('_', ' ', $pesanan->status))); ?>

                                    </span>
                                </div>
                            </div>

                            <div class="col-md-1 text-md-end">
                                <a
                                    href="<?php echo e(route('pesanan.show', $pesanan)); ?>"
                                    class="btn btn-sm btn-outline-primary"
                                >
                                    Detail
                                </a>
                            </div>

                        </div>
                    </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                    <div class="text-center py-5">
                        <i class="bi bi-basket fs-1 text-muted"></i>

                        <h5 class="fw-bold mt-3">
                            Belum Ada Pesanan
                        </h5>

                        <p class="text-muted">
                            Anda belum memiliki pesanan laundry.
                        </p>

                        <a
                            href="<?php echo e(route('pesanan.create')); ?>"
                            class="btn btn-primary"
                        >
                            Pesan Sekarang
                        </a>
                    </div>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            </div>
        </div>

        <div class="mt-4">
            <?php echo e($pesanans->links()); ?>

        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pelanggan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laundry\resources\views/pesanan/index.blade.php ENDPATH**/ ?>